/*
 * Copyright (C) 2020 Xilinx, Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#pragma once

#ifndef __QDMARW_VERSION_H
#define __QDMARW_VERSION_H

#define PROGNAME "dma-rw"
#define VERSION "2020.2.0"
#define COPYRIGHT "Copyright (c) 2020 Xilinx Inc."

#endif /*__QDMARW_VERSION_H*/
